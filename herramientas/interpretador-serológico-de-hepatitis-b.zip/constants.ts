
export const DISCLAIMER_TEXT = "Esta herramienta es un asistente basado en IA y no reemplaza el juicio clínico profesional. La interpretación y las recomendaciones generadas deben ser verificadas por un médico cualificado. El profesional sanitario es el único responsable de todas las decisiones clínicas.";
