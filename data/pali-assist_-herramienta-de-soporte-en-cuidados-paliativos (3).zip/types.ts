export enum Tab {
  Professional = 'professional',
  Family = 'family',
}

export interface Drug {
  id: string;
  name: string;
  incompatibleWith: string[];
}

export interface Interaction {
    drugs: [string, string];
    message: string;
}

export enum InfusionMode {
    Infusor = 'infusor',
    IVBag = 'ivbag',
}

export interface SymptomRecipe {
    id: string;
    name: string;
    description: string;
    drugIds: string[];
}