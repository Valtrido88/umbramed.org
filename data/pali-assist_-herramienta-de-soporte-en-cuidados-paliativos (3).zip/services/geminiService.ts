import { GoogleGenAI } from "@google/genai";
import { InfusionMode } from "../types";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

interface InfusionContext {
    drugDetails: { name: string; dose24h: number }[];
    mode: InfusionMode;
    volume: number;
    duration?: number;
}


export const getInfusionAdvice = async (context: InfusionContext): Promise<string> => {
  if (context.drugDetails.length === 0) {
    return "Por favor, añada fármacos a la perfusión para obtener recomendaciones.";
  }
  
  const drugList = context.drugDetails.map(d => `${d.name} (${d.dose24h} mg/24h)`).join(', ');

  const modeDetails = context.mode === InfusionMode.Infusor
        ? `Modo: Perfusión subcutánea con infusor/jeringa.\nVolumen total: ${context.volume} ml.\nDuración: ${context.duration} horas.`
        : `Modo: Perfusión intravenosa continua.\nVolumen total del suero: ${context.volume} ml.\nDuración: 24 horas.`;

  const prompt = `
    Eres un farmacéutico clínico experto en cuidados paliativos. Un médico necesita preparar una perfusión para un paciente terminal con los siguientes fármacos y dosis pautadas por 24 horas:
    Fármacos y dosis/24h: ${drugList}
    
    Detalles de la perfusión:
    ${modeDetails}

    Proporciona una guía de preparación detallada, estructurada y profesional. Sigue estrictamente estas instrucciones:
    
    1.  **Cálculos de Dosis y Preparación:** Realiza los cálculos para cada fármaco por separado.
        - **Si el modo es "Infusor":**
            - **Paso 1: Calcular Dosis Total.** La dosis proporcionada es para 24h. Debes calcular la dosis TOTAL necesaria para la duración COMPLETA de la perfusión. Muestra explícitamente este cálculo (ej., "Dosis Total Requerida (${context.drugDetails[0]?.dose24h}mg/24h * ${context.duration}h) = X mg"). Este es el paso más importante.
            - **Paso 2: Asumir Presentación.** Asume una presentación farmacéutica estándar para el fármaco (ej., Morfina Clorhidrato 1% es 10 mg/ml). Indica claramente la presentación que estás utilizando.
            - **Paso 3: Calcular Volumen a Cargar.** Basado en la Dosis Total y la presentación, calcula el VOLUMEN EXACTO en mililitros (ml) que se debe aspirar de la ampolla. Esta es la instrucción más importante.
        - **Si el modo es "Intravenosa (IV)":**
            - Calcula el volumen (en ml) de cada fármaco a añadir al suero para una duración de 24h, asumiendo presentaciones estándar (ej. Morfina 1% (10mg/ml), Midazolam 15mg/3ml). Especifica las presentaciones que asumes para cada cálculo.

    2.  **Dilución y Suero:** Calcula el volumen total de los fármacos cargados y determina cuánto suero (ej. Suero Salino Fisiológico 0.9%) se necesita para alcanzar el volumen final del infusor/suero.

    3.  **Orden de Carga:** Describe el orden recomendado para añadir los fármacos para minimizar riesgos de precipitación. Si el orden no es crítico, menciónalo.
    
    4.  **Resumen y Velocidad de Infusión:** Proporciona un resumen claro de la mezcla final y calcula la velocidad de infusión final en ml/hora.

    5.  **Consideraciones Críticas:** Menciona cualquier punto clave sobre estabilidad, fotosensibilidad, etc.

    Inicia tu respuesta con el encabezado "### Plan de Preparación de Perfusión".
    Finaliza con la advertencia: "Esta es una guía educativa generada por IA. Verifique siempre con el protocolo de su institución, la bibliografía farmacológica actualizada y las fichas técnicas de los medicamentos."
    Responde en español, usando un tono profesional y directo.
    `;

  try {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error fetching infusion advice:", error);
    return "Error al contactar con el servicio de IA. Por favor, inténtelo de nuevo más tarde.";
  }
};


export const getFamilyGuidance = async (topic: string): Promise<string> => {
    const prompt = `
    Eres un psicólogo y enfermero experto en cuidados paliativos. Redacta una hoja de consejos para familiares de un paciente en fase terminal. El tema es "${topic}".
    Utiliza un lenguaje claro, cercano y muy empático. Estructura la respuesta con:
    1. Un título claro y reconfortante.
    2. Una breve explicación de por qué ocurre este síntoma o situación (ej. "Es normal que duerma más", "La pérdida de apetito es parte del proceso").
    3. Una lista de consejos prácticos y compasivos sobre cómo actuar, usando guiones o asteriscos para cada punto.
    4. Un párrafo final de apoyo emocional y ánimo.

    Ejemplos de consejos prácticos:
    - Para la pérdida de apetito: No forzar la comida, ofrecer pequeñas cantidades de lo que le apetezca, centrarse en la hidratación con sorbos de agua o gelatina, y recordar que el cariño no se demuestra con comida.
    - Para el aumento del sueño: Explicar que es un mecanismo de ahorro de energía, crear un ambiente tranquilo, hablarle suavemente aunque parezca dormido, y aprovechar los momentos de lucidez para la conexión.
    - Para el cuidado de la boca: Mencionar la importancia de la higiene para evitar molestias y hongos, recomendar gasas húmedas, vaselina para los labios y enjuagues suaves.

    Adapta tu respuesta al tema específico: "${topic}". Responde en español.
    `;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        return response.text;
    } catch (error) {
        console.error("Error fetching family guidance:", error);
        return "Error al contactar con el servicio de IA. Por favor, inténtelo de nuevo más tarde.";
    }
};