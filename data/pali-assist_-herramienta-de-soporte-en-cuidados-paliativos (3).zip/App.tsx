
import React, { useState } from 'react';
import Header from './components/Header';
import ProfessionalView from './components/ProfessionalView';
import FamilyView from './components/FamilyView';
import { Tab } from './types';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Tab>(Tab.Professional);

  const renderContent = () => {
    switch (activeTab) {
      case Tab.Professional:
        return <ProfessionalView />;
      case Tab.Family:
        return <FamilyView />;
      default:
        return <ProfessionalView />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-100/50">
      <Header />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-lg border border-slate-200">
          <div className="mb-8 border-b border-slate-200">
            <nav className="-mb-px flex space-x-6" aria-label="Tabs">
              <button
                onClick={() => setActiveTab(Tab.Professional)}
                className={`${
                  activeTab === Tab.Professional
                    ? 'border-cyan-600 text-cyan-700'
                    : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                } whitespace-nowrap py-4 px-1 border-b-2 font-semibold text-lg transition-colors duration-200 focus:outline-none`}
              >
                Para Profesionales
              </button>
              <button
                onClick={() => setActiveTab(Tab.Family)}
                className={`${
                  activeTab === Tab.Family
                    ? 'border-cyan-600 text-cyan-700'
                    : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                } whitespace-nowrap py-4 px-1 border-b-2 font-semibold text-lg transition-colors duration-200 focus:outline-none`}
              >
                Para Familiares
              </button>
            </nav>
          </div>
          {renderContent()}
        </div>
        <footer className="text-center mt-8 text-slate-500 text-sm">
            <p>Pali-Assist es una herramienta conceptual. La información generada por IA puede ser imprecisa.</p>
            <p><strong>NO UTILIZAR PARA DECISIONES CLÍNICAS REALES.</strong> Consulte siempre la bibliografía y guías clínicas oficiales.</p>
        </footer>
      </main>
    </div>
  );
};

export default App;
