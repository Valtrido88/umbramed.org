
import React, { useState, useMemo, useCallback } from 'react';
import { PALLIATIVE_DRUGS, SYMPTOM_RECIPES } from '../constants';
import { Drug, Interaction, InfusionMode, SymptomRecipe } from '../types';
import { getInfusionAdvice } from '../services/geminiService';
import Spinner from './Spinner';
import AdviceDisplay from './AdviceDisplay';

const InteractionAlert: React.FC<{ interactions: Interaction[] }> = ({ interactions }) => (
    <div className="p-4 mt-4 bg-red-50 border-l-4 border-red-500 rounded-r-lg">
        <div className="flex">
            <div className="flex-shrink-0">
                <svg className="h-6 w-6 text-red-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
            </div>
            <div className="ml-3">
                <h3 className="text-lg font-bold text-red-800">¡Atención! Posible Interacción</h3>
                <div className="mt-2 text-md text-red-700">
                    <p>Se ha detectado una posible incompatibilidad fisicoquímica (riesgo de precipitación) entre:</p>
                    <ul className="list-disc list-inside mt-2">
                        {interactions.map((interaction, index) => (
                            <li key={index}><strong>{interaction.drugs[0]}</strong> y <strong>{interaction.drugs[1]}</strong></li>
                        ))}
                    </ul>
                    <p className="mt-2 font-semibold">No se recomienda la administración conjunta en la misma perfusión. Valore vías alternativas.</p>
                </div>
            </div>
        </div>
    </div>
);


const InfusionCalculator: React.FC = () => {
  const [mode, setMode] = useState<InfusionMode>(InfusionMode.Infusor);
  const [selectedDrugs, setSelectedDrugs] = useState<Drug[]>([]);
  const [drugDosages, setDrugDosages] = useState<Record<string, string>>({});
  const [volume, setVolume] = useState<string>('20');
  const [duration, setDuration] = useState<string>('24');

  const [advice, setAdvice] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const interactions = useMemo<Interaction[]>(() => {
    const foundInteractions: Interaction[] = [];
    for (let i = 0; i < selectedDrugs.length; i++) {
        for (let j = i + 1; j < selectedDrugs.length; j++) {
            const drugA = selectedDrugs[i];
            const drugB = selectedDrugs[j];
            if (drugA.incompatibleWith.includes(drugB.id) || drugB.incompatibleWith.includes(drugA.id)) {
                foundInteractions.push({
                    drugs: [drugA.name, drugB.name],
                    message: `Precipitación entre ${drugA.name} y ${drugB.name}`
                });
            }
        }
    }
    return foundInteractions;
  }, [selectedDrugs]);

  const toggleDrugSelection = useCallback((drug: Drug) => {
    setSelectedDrugs(prev => {
        const isSelected = prev.some(d => d.id === drug.id);
        if (isSelected) {
            const newDosages = { ...drugDosages };
            delete newDosages[drug.id];
            setDrugDosages(newDosages);
            return prev.filter(d => d.id !== drug.id);
        } else {
            setDrugDosages(prevDosages => ({ ...prevDosages, [drug.id]: '' }));
            return [...prev, drug];
        }
    });
  }, [drugDosages]);

  const handleDosageChange = (drugId: string, value: string) => {
    setDrugDosages(prev => ({ ...prev, [drugId]: value.replace(/[^0-9.]/g, '') }));
  };

  const handleModeChange = (newMode: InfusionMode) => {
    setMode(newMode);
    if (newMode === InfusionMode.IVBag) {
        setVolume('250');
        setDuration('24');
    } else {
        setVolume('20');
        setDuration('24');
    }
  };

  const handleRecipeSelect = (recipe: SymptomRecipe) => {
    const drugsToSelect = PALLIATIVE_DRUGS.filter(d => recipe.drugIds.includes(d.id));
    setSelectedDrugs(drugsToSelect);
    const newDosages: Record<string, string> = {};
    drugsToSelect.forEach(drug => { newDosages[drug.id] = ''; });
    setDrugDosages(newDosages);
    setAdvice('');
    setError(null);
  };
  
  const handleGenerateAdvice = useCallback(async () => {
    setError(null);
    const drugDetails = selectedDrugs.map(d => ({
        name: d.name,
        dose24h: parseFloat(drugDosages[d.id] || '0')
    })).filter(d => d.dose24h > 0);
    
    if (drugDetails.length === 0) {
        setError("Seleccione al menos un fármaco y especifique su dosis.");
        return;
    }
    if (drugDetails.length < selectedDrugs.length) {
        setError("Por favor, especifique una dosis para cada fármaco seleccionado.");
        return;
    }
    if (!volume || parseFloat(volume) <= 0) {
        setError("Introduzca un volumen total válido.");
        return;
    }
    if (mode === InfusionMode.Infusor && (!duration || parseFloat(duration) <= 0)) {
        setError("Introduzca una duración válida para el infusor.");
        return;
    }
    
    setIsLoading(true);
    setAdvice('');

    try {
        const result = await getInfusionAdvice({
            drugDetails,
            mode,
            volume: parseFloat(volume),
            duration: mode === InfusionMode.Infusor ? parseFloat(duration) : undefined,
        });
        setAdvice(result);
    } catch (err) {
        setError("Hubo un problema al generar la guía. Por favor, inténtelo de nuevo.");
        console.error(err);
    } finally {
        setIsLoading(false);
    }
  }, [selectedDrugs, drugDosages, volume, duration, mode]);

  const availableDrugs = PALLIATIVE_DRUGS.filter(
    (drug) => !selectedDrugs.some((selected) => selected.id === drug.id)
  );

  return (
    <div className="space-y-8">
      <div>
        <h3 className="text-xl font-semibold text-slate-700 mb-3">1. Planificador de Perfusión</h3>
        <div className="p-6 bg-slate-50 border border-slate-200 rounded-xl">
          <fieldset className="space-y-4">
            <legend className="text-lg font-medium text-slate-900 mb-2">Modo de Perfusión</legend>
            <div className="flex flex-col sm:flex-row gap-4">
                <button onClick={() => handleModeChange(InfusionMode.Infusor)} className={`flex-1 p-4 rounded-lg border-2 text-center transition-all duration-200 ${mode === InfusionMode.Infusor ? 'bg-cyan-50 border-cyan-500 text-cyan-800 shadow-sm' : 'bg-white border-slate-300 text-slate-600 hover:border-cyan-400 hover:bg-cyan-50/50'}`}>
                    <span className="block font-bold">Perfusión con Infusor</span>
                    <span className="text-sm">Jeringa subcutánea (ej. 10-30ml)</span>
                </button>
                <button onClick={() => handleModeChange(InfusionMode.IVBag)} className={`flex-1 p-4 rounded-lg border-2 text-center transition-all duration-200 ${mode === InfusionMode.IVBag ? 'bg-cyan-50 border-cyan-500 text-cyan-800 shadow-sm' : 'bg-white border-slate-300 text-slate-600 hover:border-cyan-400 hover:bg-cyan-50/50'}`}>
                    <span className="block font-bold">Perfusión Intravenosa (IV)</span>
                    <span className="text-sm">Suero continuo (ej. 250-500ml)</span>
                </button>
            </div>
          </fieldset>
        </div>
      </div>
      
      <div>
        <h3 className="text-xl font-semibold text-slate-700 mb-3">2. Recetas Clínicas (Opcional)</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {SYMPTOM_RECIPES.map(recipe => (
            <button key={recipe.id} onClick={() => handleRecipeSelect(recipe)} className="p-4 bg-white border border-slate-200 rounded-lg text-left hover:bg-slate-50 hover:border-slate-300 transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500">
              <p className="font-bold text-cyan-700">{recipe.name}</p>
              <p className="text-sm text-slate-500">{recipe.description}</p>
            </button>
          ))}
        </div>
      </div>

      <div>
        <h3 className="text-xl font-semibold text-slate-700 mb-3">3. Configuración de la Perfusión</h3>
        <div className="bg-white border border-slate-200 rounded-xl shadow-sm">
          <div className="p-6">
            <h4 className="font-semibold text-lg text-slate-800 mb-4">Fármacos en Perfusión</h4>
            <div className="space-y-4">
              {selectedDrugs.length === 0 ? (
                <p className="text-slate-500 text-center py-4">Seleccione fármacos de la lista de abajo o use una receta clínica.</p>
              ) : (
                selectedDrugs.map(drug => (
                  <div key={drug.id} className="flex flex-wrap items-center gap-4 p-3 bg-slate-50 rounded-lg">
                    <span className="font-semibold text-slate-700 flex-1 min-w-[120px]">{drug.name}</span>
                    <div className="flex items-center gap-2">
                      <label htmlFor={`dose-${drug.id}`} className="text-sm font-medium text-slate-600">Dosis/24h</label>
                      <input 
                        type="text" 
                        id={`dose-${drug.id}`}
                        value={drugDosages[drug.id] || ''}
                        onChange={e => handleDosageChange(drug.id, e.target.value)}
                        placeholder="ej. 10"
                        className="w-24 p-2 border border-slate-300 rounded-md shadow-sm focus:ring-cyan-500 focus:border-cyan-500 text-right"
                      />
                      <span className="text-sm text-slate-500">mg</span>
                    </div>
                    <button onClick={() => toggleDrugSelection(drug)} className="p-1 text-red-500 hover:text-red-700 hover:bg-red-100 rounded-full ml-auto">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                      </svg>
                    </button>
                  </div>
                ))
              )}
            </div>

            <hr className="my-6" />

            <h4 className="font-semibold text-lg text-slate-800 mb-4">Añadir Fármaco</h4>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
              {availableDrugs.map(drug => (
                <button
                  key={drug.id}
                  onClick={() => toggleDrugSelection(drug)}
                  className="px-3 py-2 bg-white border border-slate-300 rounded-md text-slate-700 text-sm font-medium hover:bg-cyan-50 hover:border-cyan-400 transition-colors duration-150"
                >
                  {drug.name}
                </button>
              ))}
            </div>

            {interactions.length > 0 && <InteractionAlert interactions={interactions} />}
          </div>
          
          <div className="border-t border-slate-200 bg-slate-50/70 p-6 rounded-b-xl">
            <h4 className="font-semibold text-lg text-slate-800 mb-4">Parámetros de Perfusión</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label htmlFor="volume" className="block text-sm font-medium text-slate-700 mb-1">{mode === InfusionMode.Infusor ? 'Volumen Total del Infusor' : 'Volumen Total del Suero'}</label>
                <div className="relative">
                  <input type="text" id="volume" value={volume} onChange={e => setVolume(e.target.value.replace(/[^0-9.]/g, ''))} className="w-full p-2 border border-slate-300 rounded-md shadow-sm focus:ring-cyan-500 focus:border-cyan-500"/>
                  <span className="absolute inset-y-0 right-0 pr-3 flex items-center text-sm text-slate-500">ml</span>
                </div>
              </div>
              {mode === InfusionMode.Infusor && (
                <div>
                  <label htmlFor="duration" className="block text-sm font-medium text-slate-700 mb-1">Duración de la Perfusión</label>
                  <div className="relative">
                    <input type="text" id="duration" value={duration} onChange={e => setDuration(e.target.value.replace(/[^0-9.]/g, ''))} className="w-full p-2 border border-slate-300 rounded-md shadow-sm focus:ring-cyan-500 focus:border-cyan-500" />
                    <span className="absolute inset-y-0 right-0 pr-3 flex items-center text-sm text-slate-500">horas</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      
      <div>
        <div className="mt-6">
          <button
            onClick={handleGenerateAdvice}
            disabled={isLoading || interactions.length > 0 || selectedDrugs.length === 0}
            className="w-full flex items-center justify-center px-8 py-4 border border-transparent text-lg font-bold rounded-xl shadow-lg text-white bg-cyan-600 hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500 disabled:bg-slate-400 disabled:cursor-not-allowed transition-all duration-200"
          >
            {isLoading ? (
                <>
                  <Spinner />
                  <span className="ml-3">Generando Plan...</span>
                </>
            ) : "Generar Plan de Preparación"}
          </button>
          {interactions.length > 0 && <p className="text-center text-sm text-red-600 mt-2">No se puede generar un plan debido a las interacciones detectadas.</p>}
        </div>
        
        {error && (
            <div className="mt-6 p-4 bg-red-100 border border-red-300 text-red-800 rounded-lg">
            {error}
            </div>
        )}
      </div>

      {advice && !isLoading && (
        <div>
            <h3 className="text-xl font-semibold text-slate-700 mb-3 mt-8">4. Guía de Preparación Generada por IA</h3>
            <AdviceDisplay text={advice} />
        </div>
      )}

    </div>
  );
};

export default InfusionCalculator;
