
import React from 'react';

interface AdviceDisplayProps {
  text: string;
}

const AdviceDisplay: React.FC<AdviceDisplayProps> = ({ text }) => {
  // Simple formatter to handle newlines and make text more readable
  const formattedText = text.split('\n').map((line, index) => {
    if (line.trim().startsWith('###') || line.match(/^\d+\./)) {
      return <h4 key={index} className="text-lg font-semibold text-slate-700 mt-4 mb-2">{line.replace('###', '').replace(/^\d+\./, '').trim()}</h4>;
    }
    if (line.trim().startsWith('**') && line.trim().endsWith('**')) {
        return <p key={index} className="font-bold my-2">{line.replace(/\*\*/g, '')}</p>
    }
    if (line.trim() === '') {
      return <br key={index} />;
    }
    return <p key={index} className="mb-2 text-slate-600 leading-relaxed">{line}</p>;
  });

  return (
    <div className="p-6 bg-slate-50 border border-slate-200 rounded-lg prose max-w-none">
      {formattedText}
    </div>
  );
};

export default AdviceDisplay;
