
import React from 'react';
import InfusionCalculator from './InfusionCalculator';

const ProfessionalView: React.FC = () => {
  return (
    <div>
      <h2 className="text-2xl font-bold text-slate-800 mb-2">Herramientas para Profesionales</h2>
      <p className="text-slate-600 mb-6">Utilice estas herramientas para facilitar la toma de decisiones en la práctica clínica diaria.</p>
      <InfusionCalculator />
    </div>
  );
};

export default ProfessionalView;
