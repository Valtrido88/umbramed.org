
import React, { useState, useCallback } from 'react';
import jsPDF from 'jspdf';
import { getFamilyGuidance } from '../services/geminiService';
import Spinner from './Spinner';
import AdviceDisplay from './AdviceDisplay';

const TOPICS = [
  "La pérdida de apetito y la negativa a comer",
  "El aumento del sueño y la somnolencia",
  "Cuidados de la boca para prevenir sequedad y hongos",
  "Manejo de la agitación o el delirio (sundowning)",
  "Cómo hablar con un ser querido que sabe que va a morir",
  "Cambios en la respiración al final de la vida",
];

const FamilyView: React.FC = () => {
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);
  const [guidance, setGuidance] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleTopicClick = useCallback(async (topic: string) => {
    if (isLoading && topic === selectedTopic) return;
    setSelectedTopic(topic);
    setIsLoading(true);
    setError(null);
    setGuidance('');
    try {
      const result = await getFamilyGuidance(topic);
      setGuidance(result);
    } catch (err) {
      setError('Hubo un problema al generar la guía. Por favor, inténtelo de nuevo.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, [isLoading, selectedTopic]);

  const handleDownloadPdf = () => {
    if (!guidance || !selectedTopic) return;

    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    const margin = 15;
    
    doc.setFont('Helvetica', 'bold');
    doc.setFontSize(18);
    doc.text('Pali-Assist: Guía para Familiares', pageWidth / 2, 20, { align: 'center' });

    doc.setFontSize(14);
    doc.setTextColor(100);
    doc.text(`Tema: ${selectedTopic}`, pageWidth / 2, 30, { align: 'center' });

    doc.setLineWidth(0.5);
    doc.line(margin, 35, pageWidth - margin, 35);

    doc.setFont('Helvetica', 'normal');
    doc.setFontSize(11);
    doc.setTextColor(0);
    
    const splitText = doc.splitTextToSize(guidance, pageWidth - margin * 2);
    doc.text(splitText, margin, 45);

    const finalY = doc.getTextDimensions(splitText).h + 60;
    doc.setFontSize(9);
    doc.setTextColor(150);
    const disclaimer = "Esta guía es un soporte educativo generado por IA y no reemplaza el consejo de un profesional de la salud. Consulte siempre a su equipo médico.";
    doc.text(disclaimer, pageWidth / 2, finalY > 280 ? 285 : finalY, { align: 'center', maxWidth: pageWidth - margin * 2 });

    doc.save(`Guia_Pali-Assist_${selectedTopic.replace(/ /g, '_')}.pdf`);
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-slate-800 mb-2">Apoyo para Familiares y Cuidadores</h2>
      <p className="text-slate-600 mb-6">
        Sabemos que este es un momento difícil. Aquí encontrará guías para entender mejor el proceso y cuidar a su ser querido (y a usted mismo).
        Seleccione un tema para obtener consejos.
      </p>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {TOPICS.map((topic) => (
          <button
            key={topic}
            onClick={() => handleTopicClick(topic)}
            className={`p-4 bg-cyan-50 border border-cyan-200 rounded-lg text-cyan-800 font-semibold text-left hover:bg-cyan-100 hover:border-cyan-300 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500 disabled:opacity-50 disabled:cursor-not-allowed ${selectedTopic === topic && 'ring-2 ring-cyan-500 bg-cyan-100'}`}
            disabled={isLoading}
          >
            {topic}
          </button>
        ))}
      </div>
      
      {isLoading && (
        <div className="flex justify-center items-center mt-8 p-6 bg-slate-50 rounded-lg text-cyan-700">
          <Spinner />
          <p className="ml-4 text-slate-600">Generando guía, por favor espere...</p>
        </div>
      )}

      {error && (
        <div className="mt-6 p-4 bg-red-100 border border-red-300 text-red-800 rounded-lg">
          {error}
        </div>
      )}

      {guidance && (
        <div className="mt-6">
           <div className="flex justify-between items-center mb-4">
             <h3 className="text-xl font-bold text-slate-800">Guía sobre: "{selectedTopic}"</h3>
             <button
               onClick={handleDownloadPdf}
               className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-cyan-600 hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500"
             >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                </svg>
                Descargar Guía en PDF
             </button>
           </div>
           <AdviceDisplay text={guidance} />
        </div>
      )}
    </div>
  );
};

export default FamilyView;
