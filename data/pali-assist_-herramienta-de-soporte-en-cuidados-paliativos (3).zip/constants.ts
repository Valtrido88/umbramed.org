import { Drug, SymptomRecipe } from './types';

// NOTA: Las incompatibilidades están simplificadas para esta herramienta educativa. CONSULTE SIEMPRE las guías de compatibilidad oficiales.
export const PALLIATIVE_DRUGS: Drug[] = [
  { id: 'buprenorfina', name: 'Buprenorfina', incompatibleWith: ['fenobarbital', 'haloperidol'].sort() },
  { id: 'ciclizina', name: 'Ciclizina', incompatibleWith: ['dexametasona', 'hioscina', 'morfina', 'octreotida', 'oxicodona'].sort() },
  { id: 'clonazepam', name: 'Clonazepam', incompatibleWith: ['haloperidol', 'morfina'].sort() },
  { id: 'dexametasona', name: 'Dexametasona', incompatibleWith: ['ciclizina', 'fenobarbital', 'glicopirrolato', 'haloperidol', 'hidromorfona', 'hioscina', 'ketamina', 'levomepromazina', 'midazolam', 'ondansetron', 'propofol'].sort() },
  { id: 'escopolamina', name: 'Escopolamina Butilbromuro', incompatibleWith: [] },
  { id: 'fenobarbital', name: 'Fenobarbital', incompatibleWith: ['buprenorfina', 'clonazepam', 'dexametasona', 'fentanilo', 'glicopirrolato', 'haloperidol', 'hidromorfona', 'ketamina', 'levomepromazina', 'metadona', 'midazolam', 'morfina', 'ondansetron'].sort() },
  { id: 'fentanilo', name: 'Fentanilo', incompatibleWith: ['fenobarbital'] },
  { id: 'furosemida', name: 'Furosemida', incompatibleWith: ['haloperidol', 'hidromorfona', 'ketamina', 'metoclopramida', 'midazolam', 'morfina', 'ondansetron'].sort() },
  { id: 'glicopirrolato', name: 'Glicopirrolato', incompatibleWith: ['dexametasona', 'fenobarbital'].sort() },
  { id: 'haloperidol', name: 'Haloperidol', incompatibleWith: ['buprenorfina', 'clonazepam', 'dexametasona', 'fenobarbital', 'furosemida', 'hidromorfona', 'ketamina', 'metadona', 'morfina', 'ondansetron', 'oxicodona', 'propofol'].sort() },
  { id: 'hidromorfona', name: 'Hidromorfona', incompatibleWith: ['dexametasona', 'fenobarbital', 'furosemida', 'haloperidol'].sort() },
  { id: 'hioscina', name: 'Hioscina Bromhidrato', incompatibleWith: ['ciclizina', 'dexametasona'].sort() },
  { id: 'ketamina', name: 'Ketamina', incompatibleWith: ['dexametasona', 'fenobarbital', 'furosemida', 'haloperidol', 'propofol'].sort() },
  { id: 'ketorolaco', name: 'Ketorolaco', incompatibleWith: ['haloperidol', 'midazolam', 'morfina'].sort() },
  { id: 'levomepromazina', name: 'Levomepromazina', incompatibleWith: ['dexametasona', 'fenobarbital', 'metoclopramida', 'ondansetron'].sort() },
  { id: 'metadona', name: 'Metadona', incompatibleWith: ['fenobarbital', 'haloperidol', 'midazolam', 'ondansetron'].sort() },
  { id: 'metoclopramida', name: 'Metoclopramida', incompatibleWith: ['dexametasona', 'furosemida', 'levomepromazina'].sort() },
  { id: 'midazolam', name: 'Midazolam', incompatibleWith: ['dexametasona', 'fenobarbital', 'furosemida', 'ketorolaco', 'metadona', 'propofol'].sort() },
  { id: 'morfina', name: 'Morfina', incompatibleWith: ['ciclizina', 'dexametasona', 'fenobarbital', 'furosemida', 'haloperidol', 'ondansetron', 'propofol'].sort() },
  { id: 'octreotida', name: 'Octreotida', incompatibleWith: ['ciclizina'] },
  { id: 'ondansetron', name: 'Ondansetrón', incompatibleWith: ['dexametasona', 'fenobarbital', 'furosemida', 'haloperidol', 'levomepromazina', 'metadona', 'morfina', 'propofol'].sort() },
  { id: 'oxicodona', name: 'Oxicodona', incompatibleWith: ['ciclizina', 'haloperidol'].sort() },
  { id: 'propofol', name: 'Propofol', incompatibleWith: ['dexametasona', 'haloperidol', 'ketamina', 'midazolam', 'morfina', 'ondansetron'].sort() },
  { id: 'tramadol', name: 'Tramadol', incompatibleWith: [] },
].sort((a, b) => a.name.localeCompare(b.name));

export const SYMPTOM_RECIPES: SymptomRecipe[] = [
    {
        id: 'dolor-agitacion',
        name: 'Dolor y Agitación',
        description: 'Combinación para el control del dolor severo y la agitación o ansiedad.',
        drugIds: ['morfina', 'midazolam'],
    },
    {
        id: 'delirio-nauseas',
        name: 'Delirio y Náuseas',
        description: 'Para pacientes con delirio, agitación y control de náuseas.',
        drugIds: ['haloperidol', 'metoclopramida'],
    },
    {
        id: 'estertores',
        name: 'Estertores y Secreciones',
        description: 'Fármacos para reducir las secreciones en la fase final.',
        drugIds: ['escopolamina', 'midazolam'],
    },
     {
        id: 'dolor-neuropatico',
        name: 'Dolor Neuropático y Delirio',
        description: 'Combinación útil en dolor neuropático con componente de agitación.',
        drugIds: ['levomepromazina', 'ketamina'],
    },
    {
        id: 'dolor-severo-opioide-rotacion',
        name: 'Dolor Severo / Rotación de Opioide',
        description: 'Alternativa para dolor severo o cuando se requiere rotación de morfina, con componente neuropático.',
        drugIds: ['fentanilo', 'ketamina'],
    },
    {
        id: 'agitacion-refractaria',
        name: 'Agitación Refractaria / Sedación',
        description: 'Para agitación severa o cuando se busca un nivel de sedación paliativa.',
        drugIds: ['midazolam', 'levomepromazina'],
    },
    {
        id: 'dolor-nauseas-alt',
        name: 'Dolor y Náuseas (Alternativa)',
        description: 'Opción con opioide potente (hidromorfona) y antiemético para control sintomático.',
        drugIds: ['hidromorfona', 'ondansetron'],
    }
];